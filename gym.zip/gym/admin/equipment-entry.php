<?php
session_start();
//the isset function to check username is already loged in and stored on the session
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css">
  <style>
    .fancy-form-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

.fancy-form-table td {
    padding: 10px;
    border: 1px solid #ddd;
}

.fancy-form-table label {
    font-weight: bold;
    color: #333;
}

.fancy-form-table input,
.fancy-form-table select,
.fancy-form-table textarea {
    width: 100%;
    padding: 8px;
    margin-top: 4px;
    margin-bottom: 8px;
    box-sizing: border-box;
}

.fancy-form-table select {
    width: calc(100% - 16px);
}

.fancy-form-table .help-block {
    color: #888;
    font-size: 12px;
}

.fancy-form-table button {
    padding: 10px 20px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.fancy-form-table button:hover {
    background-color: #45a049;
}
  </style>
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Equipment Entry Form</h1>
        </div> 
        <div class="report-body">
        <form action="add-equipment-req.php" method="POST" class="form-horizontal">
                    <table class="fancy-form-table">
                        <tr>
                            <td><label>Equipment:</label></td>
                            <td><input type="text" name="ename" placeholder="Equipment Name" required /></td>
                        </tr>
                        <tr>
                            <td><label>Description:</label></td>
                            <td><input type="text" name="description" placeholder="Short Description" required /></td>
                        </tr>
                        <tr>
                            <td><label>Date of Purchase:</label></td>
                            <td>
                                <input type="date" name="date" />
                                <span class="help-block">Please mention the date of purchase</span>
                            </td>
                        </tr>
                        <tr>
                            <td><label>Quantity:</label></td>
                            <td><input type="number" name="quantity" placeholder="Equipment Qty" required /></td>
                        </tr>
                        <tr>
                            <td><label>Vendor:</label></td>
                            <td><input type="text" name="vendor" placeholder="Vendor" required /></td>
                        </tr>
                        <tr>
                            <td><label>Address:</label></td>
                            <td><input type="text" name="address" placeholder="Vendor Address" required /></td>
                        </tr>
                        <tr>
                            <td><label>Contact Number:</label></td>
                            <td>
                                <input type="text" id="mask-phone" name="contact" placeholder="(999) 999-9999" minlength="10" maxlength="10" class="mask text" required>
                            </td>
                        </tr>
                        <tr>
                            <td><label>Cost Per Item($):</label></td>
                            <td>
                                <input type="number" placeholder="269" name="amount" required>
                            </td>
                        </tr>
                        <tr>
                          <td colspan="2"><button type="submit" class="btn btn-success">Submit Details</button></td>
                        </tr>
                    </table>
</form>
</div> 
    </div> 
</div> 

	</div> 

	<script src="../js/index.js"></script> 
</body> 
</html>