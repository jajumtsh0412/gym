<?php
session_start();
//the isset function to check username is already loged in and stored on the session
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css"> 
<style>
    body {
        font-family: 'Arial', sans-serif;
        font-size: 14px;
        line-height: 1.6;
        color: #333;
        background-color: #f4f4f4;
    }

    .body-wrap {
        margin: 20px;
    }

    .container {
        max-width: 600px;
        margin: 0 auto;
    }

    .content {
        background-color: #fff;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .main {
        width: 100%;
    }

    .content-wrap {
        text-align: center;
    }

    .invoice {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .invoice td {
        border: 1px solid #ddd;
        padding: 8px;
    }

    .invoice-items td {
        padding: 10px;
    }

    .invoice-items td b {
        font-weight: bold;
    }

    .total {
        background-color: #f8f8f8;
    }

    .footer {
        margin-top: 20px;
    }

    .content-block {
        margin-bottom: 20px;
    }

    .text-center {
        text-align: center;
    }

    .alignright {
        text-align: right;
    }

    .aligncenter {
        text-align: center;
    }

    .btn {
        padding: 10px 20px;
        background-color: #d9534f;
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    .btn:hover {
        background-color: #c9302c;
    }
</style>

</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Payments</h1>
        </div> 
        <div class="report-body">
<form role="form" action="index.php" method="POST">
    <?php 

            if(isset($_POST['amount'])){ 

            $fullname = $_POST['fullname'];
            $paid_date = $_POST['paid_date'];
            // $p_year = date('Y');
            $services = $_POST["services"];
            $amount = $_POST["amount"];
            $plan = $_POST["plan"];
            $status = $_POST["status"];
            $id=$_POST['id'];
            

            $amountpayable = $amount * $plan;
            
            include 'dbcon.php';
            date_default_timezone_set('Asia/Kathmandu');
            //$current_date = date('Y-m-d h:i:s');
                $current_date = date('Y-m-d h:i A');
                $exp_date_time = explode(' ', $current_date);
                $curr_date =  $exp_date_time['0'];
                $curr_time =  $exp_date_time['1']. ' ' .$exp_date_time['2'];
            //code after connection is successfull
            //update query
            $qry = "UPDATE members SET amount='$amountpayable', plan='$plan', status='$status', paid_date='$curr_date', reminder='0' WHERE user_id='$id'";
            $result = mysqli_query($con,$qry); //query executes

            if(!$result){ ?>

                <h3 class="text-center">Something went wrong!</h3>
                
             <?php } else { ?>

              <?php if ($status == 'Active') {?> 
            
                <table class="body-wrap">
                <tbody><tr>
                    <td></td>
                    <td class="container" width="600">
                        <div class="content">
                            <table class="main" width="100%" cellpadding="0" cellspacing="0">
                                <tbody><tr>
                                    <td class="content-wrap aligncenter print-container">
                                        <table width="100%" cellpadding="0" cellspacing="0">
                                            <tbody><tr>
                                                <td class="content-block">
                                                    <h3 class="text-center">Payment Receipt</h3>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="content-block">
                                                    <table class="invoice">
                                                        <tbody>
                                                        <tr>
                                                            <td><div style="float:left">Invoice #GMS_<?php echo(rand(100000,10000000));?> <br> 5021  Wetzel Lane, <br>Williamsburg </div><div style="float:right"> Last Payment: <?php echo $paid_date?></div></td>
                                                        </tr>

                                                        <tr>
                                                        <td class="text-center" style="font-size:14px;"><b>Member: <?php echo $fullname; ?></b>  <br>
                                                          Paid On: <?php echo date("F j, Y - g:i a");?>
                                                        </td>
                                                        
                                                        </tr>
                                                       
                                                        <tr>
                                                            <td>
                                                                <table class="invoice-items" cellpadding="0" cellspacing="0">
                                                                    <tbody>
                                                                    
                                                                    <tr>
                                                                        <td><b>Service Taken</b></td>
                                                                        <td class="alignright"><b>Valid Upto</b></td>
                                                                    </tr>
                                                                    
                                                                    
                                                                    <tr>
                                                                        <td><?php echo $services; ?></td>
                                                                        <td class="alignright"><?php echo $plan?> Month/s</td>
                                                                    </tr>

                                                                    <tr>
                                                                        <td><?php echo 'Charge Per Month'; ?></td>
                                                                        <td class="alignright"><?php echo '$'.$amount?></td>
                                                                    </tr>
                                                                   
                                                                    
                                                                    <tr class="total">
                                                                        <td class="alignright" width="80%">Total Amount</td>
                                                                        <td class="alignright">$<?php echo $amountpayable; ?></td>
                                                                    </tr>
                                                                </tbody></table>
                                                            </td>
                                                        </tr>
                                                    </tbody></table>
                                                </td>
                                            </tr>
                                            
                                            <tr>
                                                <td class="content-block text-center">
                                                We sincerely appreciate your promptness regarding all payments from your side.
                                                </td>
                                            </tr>
                                        </tbody></table>
                                    </td>
                                </tr>
                            </tbody></table>
                            <div class="footer">
                                <table width="100%">
                                    <tbody><tr>
                                        <td class="aligncenter content-block"><button class="btn btn-danger" onclick="window.print()"><i class="fas fa-print"></i> Print</button></td>
                                    </tr>
                                </tbody></table>
                            </div></div>
                    </td>
                    <td></td>
                </tr>
            </tbody>
            </table>
            
           <?php } else {?>

            <div class='error_ex'>
            <h1>409</h1>
            <h3>Looks like you've deactivated the customer's account!</h3>
            <p>The selected member's account will no longer be ACTIVATED until the next payment.</p>
            <a class='btn btn-danger btn-big'  href='payment.php'>Go Back</a> </div>

           <?php } ?>

         <?php   }

          } else { ?>
              <h3>YOU ARE NOT AUTHORIZED TO REDIRECT THIS PAGE. GO BACK to <a href='index.php'> DASHBOARD </a></h3>
       <?php }
?>
                                                               
                
             </form>
             </div> 
    </div> 
</div> 

	</div> 

	<script src="../js/index.js"></script> 
</body> 
</html>