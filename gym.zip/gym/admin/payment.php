<?php
session_start();
//the isset function to check username is already loged in and stored on the session
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css"> 
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Registered Member's Payment</h1>
        </div> 
        <div class="report-body">	  
	  <?php

      include "dbcon.php";
      $qry="SELECT * FROM members";
      $cnt = 1;
        $result=mysqli_query($con,$qry);
          echo"<table id='report-table'>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Member</th>
                  <th>Last Payment Date</th>
                  <th>Amount</th>
                  <th>Choosen Service</th>
                  <th>Plan</th>
                  <th>Action</th>
                  <th>Remind</th>
                </tr>
              </thead>";
              
            while($row=mysqli_fetch_array($result)){ ?>
            
            <tbody> 
               
                <td><?php echo $cnt;?></td>
                <td><?php echo $row['fullname']?></td>
                <td><?php echo($row['paid_date'] == 0 ? "New Member" : $row['paid_date'])?></td>
                
                <td><?php echo '$'.$row['amount']?></td>
                <td><?php echo $row['services']?></td>
                <td><?php echo $row['plan']." Month/s"?></td>
                <td><a href='user-payment.php?id=<?php echo $row['user_id']?>'>Make Payment</button></a></td>
                <td><a href='sendReminder.php?id=<?php echo $row['user_id']?>'><button class='btn btn-danger btn' <?php echo($row['reminder'] == 1 ? "disabled" : "")?>>Alert</button></a></td>
              </tbody>
          <?php $cnt++; }

            ?>

            </table>
            </div> 
    </div> 
</div> 

	</div> 

	<script src="../js/index.js"></script> 
</body> 
</html>