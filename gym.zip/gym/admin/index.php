<?php
session_start();
//the isset function to check username is already loged in and stored on the session
if(!isset($_SESSION['user_id'])){
header('location:../index.php');	
}
include "dbcon.php";
$qry="SELECT services, count(*) as number FROM members GROUP BY services";
$result=mysqli_query($con,$qry);
$qry="SELECT gender, count(*) as enumber FROM members GROUP BY gender";
$result3=mysqli_query($con,$qry);
$qry="SELECT designation, count(*) as snumber FROM staffs GROUP BY designation";
$result5=mysqli_query($con,$qry);
?>
<!DOCTYPE html>

<html lang="en">
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css">
</head>
<body>
<?php include 'includes/topheader.php'; ?>
<?php
	$page='dashboard';
	include 'includes/sidebar.php';
?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Dashboard</h1>
        </div> 
        <div class="report-body">
	<table id="report-table">
		<tr>
			<th>Active Members</th>
			<th>Registered Members</th>
			<th>Total Earnings ($)</th>
			<th>Announcements</th>
		</tr>
		<tr>
			<td><?php include'actions/dashboard-activecount.php'?></td>
			<td><?php include'dashboard-usercount.php'?></td>
			<td><?php include'income-count.php' ?></td>
			<td><?php include'actions/count-announcements.php'?></td>
		</tr>
	</table>
	<br>
	<br>
		<table id="report-table">
		<tr>
			<th>Total Members</th>
			<th>Staff Users</th>
			<th>Available Equipments</th>
			<th>Total Expenses</th>
			<th>Active Gym Trainers</th>
			<th>Present Members</th>
		</tr>
		<tr>
			<td><?php include 'dashboard-usercount.php';?></td>
			<td><?php include 'actions/dashboard-staff-count.php';?></td>
			<td><?php include 'actions/count-equipments.php';?></td>
			<td><?php include 'actions/total-exp.php';?></td>
			<td><?php include 'actions/count-trainers.php';?></td>
			<td><?php include 'actions/count-attendance.php';?></td>
		</tr>
	</table>
</div> 
    </div> 
</div>
	</div>
</body> 
</html>
