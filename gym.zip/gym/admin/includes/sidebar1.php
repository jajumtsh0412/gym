<div class="navbar">
    <ul>
        <li>
            <a href="index.php">Dashboard</a>
        </li>
        <li>
            <a href="javascript:void(0)" class="dropbtn">Manage Members</a>
			<div class="dropdown-content">
				<a href="members.php">List All Members</a>
				<a href="member-entry.php">Member Entry Form</a>
				<a href="remove-member.php">Remove Member</a>
				<a href="edit-member.php">Update Member Details</a>
			</div>
		</li>
        <li>
            <a href="javascript:void(0)" class="dropbtn">Gym Equipment</a>
			<div class="dropdown-content">
				<a href="equipment.php">List Gym Equipment</a>
				<a href="equipment-entry.php">Add Equipment</a>
				<a href="remove-equipment.php">Remove Equipment</a>
				<a href="edit-equipment.php">Update Equipment Details</a>
			</div>
		</li>
        <li class="<?php echo ($page == 'attendance') ? 'active' : ''; ?>">
            <a href="javascript:void(0)" class="dropbtn">Attendance</a>
			<div class="dropdown-content">
				<a href="attendance.php">Check In/Out</a>
				<a href="view-attendance.php">View</a>
            </div>
		</li>
        <li class="<?php echo ($page == 'manage-customer-progress') ? 'active' : ''; ?>">
            <a href="customer-progress.php">Manage Customer Progress</a>
        </li>
        <li class="<?php echo ($page == 'member-status') ? 'active' : ''; ?>">
            <a href="member-status.php">Member's Status</a>
        </li>
        <li class="<?php echo ($page == 'payment') ? 'active' : ''; ?>">
            <a href="payment.php">Payments</a>
        </li>
        <li class="<?php echo ($page == 'announcement') ? 'active' : ''; ?>">
            <a href="announcement.php">Announcement</a>
        </li>
        <li>
            <a href="javascript:void(0)" class="dropbtn">Reports</a>
			<div class="dropdown-content">
                    <a href="reports.php">Chart Representation</a>
                    <a href="members-report.php">Members Report</a>
                    <a href="progress-report.php">Customer Progress Report</a>
			</div>
       </li>
    </ul>
</div>