	<!-- for header part -->
	<header>
		<div class="logosec"> 
			<div class="logo">Perfect Gym System</div>
		</div>
		<div class="message">  
				<a href="../logout.php">Logout</a>
		</div>
	</header>