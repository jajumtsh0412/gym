<nav>
	<ul class="menu">
		<li>
			<a href="index.php">Dashboard</a>
		</li>
		<li>
			<a href="#">Manage Members</a>
			<ul class="sub-menu">
				<li><a href="members.php">List All Members</a></li>
				<li><a href="member-entry.php">Member Entry Form</a></li>
				<li><a href="remove-member.php">Remove Member</a></li>
				<li><a href="edit-member.php">Update Member Details</a></li>
			</ul>
		</li>
		<li>
			<a href="#">Gym Equipment</a>
			<ul class="sub-menu">
				<li><a href="equipment.php">List Gym Equipment</a></li>
				<li><a href="equipment-entry.php">Add Equipment</a></li>
				<li><a href="remove-equipment.php">Remove Equipment</a></li>
				<li><a href="edit-equipment.php">Update Equipment Details</a></li>
			</ul>
		</li>
		<li>
			<a href="#">Attendance</a>
			<ul class="sub-menu">
				<li><a href="attendance.php">Check In/Out</a></li>
				<li><a href="view-attendance.php">View</a></li>
			</ul>
		</li>
		<li>
			<a href="customer-progress.php">Manage Customer Progress</a>
		</li>
		<li>
			<a href="member-status.php">Member's Status</a>
		</li>
		<li>
			<a href="payment.php">Payments</a>
		</li>
		<li>
			<a href="#">Announcement</a>
			<ul class="sub-menu">
				<li><a href="announcement.php">View Announcement</a></li>
				<li><a href="manage-announcement.php">Manage Announcement</a></li>
			</ul>
		</li>
		<li>
			<a href="#">Staff</a>
			<ul class="sub-menu">
				<li><a href="staffs.php">Staff List</a></li>
				<li><a href="staffs-entry.php">Add Staff</a></li>
			</ul>
		</li>
		<li>
			<a href="#">Reports</a>
			<ul class="sub-menu">
				<li><a href="members-report.php">Members Report</a></li>
				<li><a href="progress-report.php">Customer Progress Report</a></li>
			</ul>
		</li>
	</ul>
</nav>