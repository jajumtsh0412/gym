<?php
session_start();
//the isset function to check username is already loged in and stored on the session
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css">
  <style>
  /* Add your custom CSS styles here */
  table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
  }

  table, th, td {
    border: 1px solid #ddd;
  }

  th, td {
    padding: 10px;
    text-align: left;
  }

  th {
    background-color: #f2f2f2;
  }
  td{
    width: 50%;
  }

  .form-horizontal {
    max-width: 100%;
  }

  .control-group {
    margin-bottom: 15px;
  }

  .controls {
    margin-left: 120px; /* Adjust as needed */
  }

  .form-actions {
    margin-top: 20px;
  }

  .btn {
    padding: 10px 20px;
    font-size: 16px;
  }

  input {
    width: 70%;
    padding: 8px;
    margin-top: 4px;
    margin-bottom: 8px;
    box-sizing: border-box;
  }
</style>
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Equipment Entry Form</h1>
        </div> 
        <div class="report-body">
    <?php
        include 'dbcon.php';
        $id=$_GET['id'];
        $qry= "select * from equipment where id='$id'";
        $result=mysqli_query($con,$qry);
        while($row=mysqli_fetch_array($result)){
    ?> 
<form action="edit-equipment-req.php" method="POST" class="form-horizontal">
  <table>
    <tr>
      <th colspan="2">Equipment Details</th>
    </tr>
    <tr>
      <td>Equipment Name :</td>
      <td><input type="text" name="name" value='<?php echo $row['name']; ?>' required></td>
    </tr>
    <tr>
      <td>Description :</td>
      <td><input type="text" name="description" value='<?php echo $row['description']; ?>' required></td>
    </tr>
    <tr>
      <td>Date of Purchase :</td>
      <td><input type="date" name="date" value='<?php echo $row['date']; ?>'></td>
    </tr>
    <tr>
      <td>Quantity :</td>
      <td><input type="number" name="quantity" value='<?php echo $row['quantity']; ?>' required></td>
    </tr>
  </table>

  <table>
    <tr>
      <th colspan="2">Other Details</th>
    </tr>
    <tr>
      <td>Contact Number :</td>
      <td>
        <input type="text" id="mask-phone" name="contact" placeholder="(999) 999-9999" minlength="10" maxlength="10" value='<?php echo $row['contact']; ?>' required>
      </td>
    </tr>
    <tr>
      <td>Vendor :</td>
      <td><input type="text" name="vendor" value='<?php echo $row['vendor']; ?>' required></td>
    </tr>
    <tr>
      <td>Address :</td>
      <td><input type="text" name="address" value='<?php echo $row['address']; ?>' required></td>
    </tr>
  </table>

  <table>
    <tr>
      <th colspan="2">Pricing</th>
    </tr>
    <tr>
      <td>Total Cost ($):</td>
      <td>
        <input type="number" placeholder="120000" name="amount" value='<?php echo $row['amount']; ?>' required>
      </td>
    </tr>
  </table>

  <div class="form-actions text-center">
    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
    <button type="submit" class="btn btn-success">Submit Details</button>
  </div>
</form>

          <?php
        }
    ?>
</div> 
    </div> 
</div> 

	</div> 

	<script src="../js/index.js"></script> 
</body> 
</html>