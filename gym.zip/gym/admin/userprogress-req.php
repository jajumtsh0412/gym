<?php
session_start();
//the isset function to check username is already loged in and stored on the session
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css"> 
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Registered Members List</h1>
        </div> 
        <div class="report-body"> 
<form role="form" action="index.php" method="POST">
    <?php 

            if(isset($_POST['ini_weight'])){ 
            $ini_weight = $_POST["ini_weight"];
            $curr_weight = $_POST["curr_weight"];
            $ini_bodytype = $_POST["ini_bodytype"];
            $curr_bodytype = $_POST["curr_bodytype"];
            $id=$_POST['id'];
            
            include 'dbcon.php';
            date_default_timezone_set('Asia/Kathmandu');
            //$current_date = date('Y-m-d h:i:s');
                $current_date = date('Y-m-d h:i A');
              $exp_date_time = explode(' ', $current_date);
                $curr_date =  $exp_date_time['0'];
                $curr_time =  $exp_date_time['1']. ' ' .$exp_date_time['2'];
            //code after connection is successfull
            //update query
            $qry = "update members set ini_weight='$ini_weight', curr_weight='$curr_weight', ini_bodytype='$ini_bodytype', curr_bodytype='$curr_bodytype', progress_date='$curr_date' where user_id='$id'";
            $result = mysqli_query($con,$qry); //query executes

            if(!$result){
                echo"<div class='container-fluid'>";
                    echo"<div class='row-fluid'>";
                    echo"<div class='span12'>";
                    echo"<div class='widget-box'>";
                    echo"<div class='widget-title'> <span class='icon'> <i class='fas fa-info'></i> </span>";
                        echo"<h5>Error Message</h5>";
                        echo"</div>";
                        echo"<div class='widget-content'>";
                            echo"<div class='error_ex'>";
                            echo"<h1 style='color:maroon;'>Error 404</h1>";
                            echo"<h3>Error occured while updating your details</h3>";
                            echo"<p>Please Try Again</p>";
                            echo"<a class='btn btn-warning btn-big'  href='customer-progress.php'>Go Back</a> </div>";
                        echo"</div>";
                        echo"</div>";
                    echo"</div>";
                    echo"</div>";
                echo"</div>";
            }else {

                echo"<div class='container-fluid'>";
                    echo"<div class='row-fluid'>";
                    echo"<div class='span12'>";
                    echo"<div class='widget-box'>";
                    echo"<div class='widget-title'> <span class='icon'> <i class='fas fa-briefcase'></i> </span>";
                        echo"<h5>Administrator</h5>";
                        echo"</div>";
                        echo"<div class='widget-content'>";
                            echo"<div class='error_ex'>";
                            echo"<h1>Successfull</h1>";
                            echo"<h3>Changes Done Succefully!</h3>";
                            echo"<p>The requested user's progress has been updated. Please click the button to go back.</p>";
                            echo"<a class='btn btn-inverse btn-big'  href='index.php'>Return Home</a> </div>";
                        echo"</div>";
                        echo"</div>";
                    echo"</div>";
                    echo"</div>";
                echo"</div>";

            }

            }else{
                echo"<h3>YOU ARE NOT AUTHORIZED TO REDIRECT THIS PAGE. GO BACK to <a href='index.php'> DASHBOARD </a></h3>";
            }
?>
                                                               
                
             </form>
                 </div> 
    </div> 
</div> 

	</div> 

	<script src="../js/index.js"></script> 
</body> 
</html>