<?php
session_start();
//the isset function to check username is already loged in and stored on the session
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css"> 
  <style>
        .btn {
      background-color: #5cb85c;
      color: #fff;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .btn:hover {
      background-color: #4cae4c;
    }
  input {
    width: 70%;
    padding: 8px;
    margin-top: 4px;
    margin-bottom: 8px;
    box-sizing: border-box;
  }

  select {
    width: 70%;
    padding: 8px;
    margin-top: 4px;
    margin-bottom: 8px;
    box-sizing: border-box;
  }
  </style>
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">GYM's Staff Entry Form</h1>
        </div> 
        <div class="report-body">
        <form action="added-staffs.php" method="POST">
  <table id="report-table">
    <tbody>
      <tr>
        <td>
          <label>Enter Staff's Fullname</label>
        </td>
        <td>
          <input type="text" name="fullname" required/>
        </td>
      </tr>

      <tr>
        <td>
          <label>Enter a Username</label>
        </td>
        <td>
          <input type="text" name="username" />
        </td>
      </tr>

      <tr>
        <td>
          <label>Password</label>
        </td>
        <td>
          <input type="password" name="password" />
        </td>
      </tr>

      <tr>
        <td>
          <label>Confirm Password</label>
        </td>
        <td>
          <input type="password" name="password2" />
        </td>
      </tr>

      <tr>
        <td>
          <label>Email ID</label>
        </td>
        <td>
          <input type="text" name="email" required/>
        </td>
      </tr>

      <tr>
        <td>
          <label>Address</label>
        </td>
        <td>
          <input type="text" name="address" required/>
        </td>
      </tr>

      <tr>
        <td>
          <label>Designation</label>
        </td>
        <td>
          <select name="designation">
            <option value="Cashier">Cashier</option>
            <option value="Trainer">Trainer</option>
            <option value="GYM Assistant">GYM Assistant</option>
            <option value="Front Desk Staff">Front Desk Staff</option>
            <option value="Manager">Manager</option>
          </select>
        </td>
      </tr>

      <tr>
        <td>
          <label>Gender</label>
        </td>
        <td>
          <select name="gender">
            <option value="Male">Male</option>
            <option value="Female">Female</option>
          </select>
        </td>
      </tr>

      <tr>
        <td>
          <label>Contact Number</label>
        </td>
        <td>
          <input type="number" name="contact" required />
        </td>
      </tr>
      <tr>
        <td align="center">
          <input class="btn" type="reset" value="Back" />
        </td>
        <td align="center">
          <input class="btn" type="submit" value="Proceed Next Step" />
        </td>
      </tr>
    </tbody>
  </table>

  <div>

    <div></div>
  </div>
  <div></div>
</form>

            </div> 
    </div> 
</div> 

	</div> 

	<script src="../js/index.js"></script> 
</body> 
</html>