<?php
session_start();
//the isset function to check username is already loged in and stored on the session
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css"> 
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Registered Members List</h1>
        </div> 
        <div class="report-body"> 
            <table id="report-table" cellspacing="20">
				<tr> 
					<th>#</th>
					<th>Fullname</th>
					<th>Username</th>
					<th>Gender</th>
					<th>Contact Number</th>
					<th>D.O.B</th>
					<th>Address</th>
					<th>Amount</th>
					<th>Choosen Service</th>
					<th>Plan</th>
				</tr>
				<?php
				include "dbcon.php";
				$qry = "select * from members";
				$cnt = 1;
				$result = mysqli_query($con, $qry);
				while ($row = mysqli_fetch_array($result)) {
					echo "<tr>
							<td>" . $cnt . "</td>
							<td>" . $row['fullname'] . "</td>
							<td>@" . $row['username'] . "</td>
							<td>" . $row['gender'] . "</td>
							<td>" . $row['contact'] . "</td>
							<td>" . $row['dor'] . "</td>
							<td>" . $row['address'] . "</td>
							<td>$" . $row['amount'] . "</td>
							<td>" . $row['services'] . "</td>
							<td>" . $row['plan'] . " Month/s</td>
						  </tr>";
					$cnt++;
				}
				?>
            </table>
        </div> 
    </div> 
</div> 

	</div> 

	<script src="../js/index.js"></script> 
</body> 
</html>
