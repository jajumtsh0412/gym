<?php
session_start();
//the isset function to check username is already loged in and stored on the session
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css"> 
  <style>
  .btn {
    padding: 10px 20px;
    font-size: 16px;
  }

  input {
    width: 70%;
    padding: 8px;
    margin-top: 4px;
    margin-bottom: 8px;
    box-sizing: border-box;
  }

  textarea {
    width: 100%;
    padding: 8px;
    margin-top: 4px;
    margin-bottom: 8px;
    box-sizing: border-box;
  }
</style>
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Add Announcement</h1>
        </div> 
        <div class="report-body">
        <form action="post-announcement.php" method="POST">
    <table id="report-table">
        <tr>
            <td colspan="2">
                <textarea class="span12" name="message" rows="6" placeholder="Enter text ..."></textarea>
            </td>
        </tr>
        <tr>
            <td>
                <label for="Announce Date">Applied Date:</label>
            </td>
            <td>
                <input type="date" name="date">
            </td>
        </tr>
        <tr>
            <td colspan="2" class="text-center">
                <button type="submit" class="btn">Publish Now</button>
            </td>
        </tr>
    </table>
</form>

          </div> 
    </div> 
</div> 
</div>
	<script src="../js/index.js"></script> 
</body> 
</html>