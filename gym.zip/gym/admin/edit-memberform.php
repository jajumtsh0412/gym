<?php
session_start();
//the isset function to check username is already loged in and stored on the session
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css">
  <style>
.simple-form-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

.simple-form-table td {
    padding: 10px;
    border: 1px solid #ddd;
}

.simple-form-table label {
    font-weight: bold;
    color: #333;
}

.simple-form-table input,
.simple-form-table select,
.simple-form-table textarea {
    width: 100%;
    padding: 8px;
    margin-top: 4px;
    margin-bottom: 8px;
    box-sizing: border-box;
}

.simple-form-table select {
    width: calc(100% - 16px);
}

.simple-form-table .help-block {
    color: #888;
    font-size: 12px;
}

.simple-form-table button {
    padding: 10px 20px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.simple-form-table button:hover {
    background-color: #45a049;
}

/* Add your responsive styles here if needed */

  </style>
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
  <?php
include 'dbcon.php';
$id=$_GET['id'];
$qry= "select * from members where user_id='$id'";
$result=mysqli_query($con,$qry);
while($row=mysqli_fetch_array($result)){?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Registered Members List</h1>
        </div> 
        <div class="report-body">
        <form action="edit-member-req.php" method="POST" class="form-horizontal">
    <table class="simple-form-table">
        <tr>
            <td><label>Full Name :</label></td>
            <td><input type="text" name="fullname" value='<?php echo $row['fullname']; ?>'></td>
        </tr>
        <tr>
            <td><label>Username :</label></td>
            <td><input type="text" name="username" value='<?php echo $row['username']; ?>'></td>
        </tr>
        <tr>
            <td><label>Password :</label></td>
            <td>
                <input type="password" name="password" disabled="" placeholder="**********">
                <span class="help-block">Note: Only the members are allowed to change their password until and unless it's an emergency.</span>
            </td>
        </tr>
        <tr>
            <td><label>Gender :</label></td>
            <td>
                <select name="gender" required="required">
                    <option value="Male" selected="selected">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </td>
        </tr>
        <tr>
            <td><label>D.O.R :</label></td>
            <td>
                <input type="date" name="dor" value='<?php echo $row['dor']; ?>'>
                <span class="help-block">Date of registration</span>
            </td>
        </tr>
        <tr>
            <td><label>Plans:</label></td>
            <td>
                <select name="plan" required="required">
                    <option value="30" selected="selected">One Month</option>
                    <option value="90">Three Month</option>
                    <option value="180">Six Month</option>
                    <option value="365">One Year</option>
                </select>
            </td>
        </tr>
        <tr>
            <td><label>Contact Number</label></td>
            <td>
                <input type="number" id="mask-phone" name="contact" value='<?php echo $row['contact']; ?>' class="mask text">
                <span class="help-block blue">(999) 999-9999</span>
            </td>
        </tr>
        <tr>
            <td><label>Address :</label></td>
            <td><input type="text" name="address" value='<?php echo $row['address']; ?>'></td>
        </tr>
        <tr>
            <td><label>Services</label></td>
            <td>
                <label><input type="radio" value="Fitness" name="services"> Fitness <small>- $55 per month</small></label>
                <label><input type="radio" value="Sauna" name="services"> Sauna <small>- $35 per month</small></label>
                <label><input type="radio" value="Cardio" name="services"> Cardio <small>- $40 per month</small></label>
            </td>
        </tr>
        <tr>
            <td><label>Total Amount ($)</label></td>
            <td>
                <div class="input-append">
                    <input type="text" name="amount" value='<?php echo $row['amount']; ?>'>
                </div>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="hidden" name="id" value="<?php echo $row['user_id']; ?>">
                <button type="submit" class="btn btn-success">Update Member Details</button>
            </td>
        </tr>
    </table>
</form>
<?php } ?> 
        </div> 
    </div> 
</div>
	</div>
	<script src="../js/index.js"></script> 
</body> 
</html>