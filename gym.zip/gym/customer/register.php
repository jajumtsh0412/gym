<?php session_start();
include('dbcon.php'); ?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="../css/custom.css">
<title> Perfect Gym System </title>
</head>
<body>
  <body>
    <div class="login-page">
      <div class="form">
        <div class="login">
          <div class="login-header">
            <h3>Registration Form</h3>
            <p>Enter your details below and we will send your details for further activation process.</p>
          </div>
        </div>
        <form id="recoverform" action="pages/register-cust.php" method="POST" class="form-vertical">
          <input type="text" name="fullname" placeholder="Fullname" />
		  <input type="text" name="username" placeholder="@username" />
		  <input type="password" name="password" placeholder="Password" />
		  <input type="number" name="contact" placeholder="7878787878" />
		  <input type="text" name="address" placeholder="Address" />
		  <select name="gender" required="required" id="select">
			<option value="Male" selected="selected">Male</option>
			<option value="Female">Female</option>
			<option value="Other">Other</option>
		  </select>
		  <select name="plan" required="required" id="select">
			<option selected="true" disabled="disabled">Select Plans</option>
				<option value="1" >One Month</option>
				<option value="3">Three Month</option>
				<option value="6">Six Month</option>
				<option value="12">One Year</option>
		  </select>
		  <select name="services" required="required" id="select">
			<option selected="true" disabled="disabled">Select Service</option>
			<option value="Fitness" >Fitness</option>
			<option value="Sauna">Sauna</option>
			<option value="Cardio">Cardio</option>
		  </select>
          <input type="submit" name="submit" value="Submit" />
          <p class="message"><a href="index.php">Back to login</a></p>
        </form>
      </div>
    </div>
</body>
</body>
</html>
