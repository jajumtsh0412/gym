<?php
session_start();
session_destroy();
header('location:index.php');
?><!-- Visit dopedevelopers.com for more projects -->