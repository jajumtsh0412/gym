<?php
session_start();
//the isset function to check username is already loged in and stored on the session
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css">
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Gym Announcement</h1>
        </div> 
        <div class="report-body">
        <?php
            include "dbcon.php";
            $qry="select * from announcements";
            $result=mysqli_query($con,$qry);

            echo"<table id='report-table'>
              <thead>
                <tr>
                  <th>Message</th>
                  <th>Date</th>
                  <th>Author</th>
                </tr>
              </thead><tbody>";
              while($row=mysqli_fetch_array($result)){
              echo"<tr>
                  <td>".$row['message']."</td>
                  <td><span class='in-progress'>".$row['date']."</span></td>
                  <td>System Administrator</td>
                </tr>";
			  }
        ?>
			</tbody>
            </table>   
</div> 
</div> 
</div> 
</div> 
</body> 
</html>