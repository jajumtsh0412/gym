<?php
session_start();
//the isset function to check username is already loged in and stored on the session
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css"> 
	<style>
	
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: #fff;
        }

        .form-actions {
            margin-top: 20px;
        }

        .btn {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #45a049;
        }

        #status {
            margin-top: 10px;
            font-weight: bold;
        }
		
		input[type="text"],
        select {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
            border-radius: 5px;
        }

		</style>
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">To-Do Lists</h1>
        </div> 
        <div class="report-body">
            <form id="form-wizard" class="form-horizontal" action="actions/modified-todo.php" method="POST">
              <?php
      include 'dbcon.php';
      $id=$_GET['id'];
      $qry= "select * from todo where id='$id'";
      $result=mysqli_query($con,$qry);
      while($row=mysqli_fetch_array($result)){ ?>
        <table>
            <tr>
                <th colspan="2">Task Details</th>
            </tr>
            <tr>
                <td>Please Enter Your Task:</td>
                <td><input type="text" name="task_desc" value='<?php echo $row['task_desc']; ?>'></td>
            </tr>
            <tr>
                <td>Please Select a Status:</td>
                <td>
                    <select name="task_status" required="required">
                        <option value="In Progress">In Progress</option>
                        <option value="Pending">Pending</option>
                    </select>
                </td>
            </tr>
        </table>

        <div class="form-actions">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <input id="add" class="btn btn-primary" type="submit" value="Save Changes" />
            <div id="status"></div>
        </div>
        <div id="submitted"></div>
	  <?php } ?>
    </form>
</div> 
    </div> 
</div> 

	</div> 

	<script src="../js/index.js"></script> 
</body> 
</html>