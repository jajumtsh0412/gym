<?php
session_start();
//the isset function to check username is already loged in and stored on the session
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css"> 
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Attendance Table</h1>
        </div> 
        <div class="report-body">
	<form role="form" action="index.php" method="POST">  
    <?php
        include 'session.php';
        if(isset($_POST['task_desc'])){   
        $task_status = $_POST["task_status"];
        $task_desc = $_POST["task_desc"];
        $user_id = $session_id;
        include 'dbcon.php';
        
        //code after connection is successfull
        $qry = "insert into todo(task_status,task_desc,user_id) values ('$task_status','$task_desc','$user_id')";
        $result = mysqli_query($con,$qry); //query executes

            if(!$result){
                        echo"<h1 style='color:maroon;'>Error 404</h1>";
                        echo"<h3>Error occured while entering your details</h3>";
                        echo"<p>Please Try Again</p>";
                        echo"<a class='btn btn-warning btn-big'  href='index.php'>Go Back</a>";
            }else {
                        echo"<h1>Success</h1>";
                        echo"<h3>Your task has been added!</h3>";
                        echo"<p>Please click the button to go back.</p>";
                        echo"<a class='btn btn-inverse btn-big'  href='index.php'>Go Back</a>";
            }

            }else{
                echo"<h3>YOU ARE NOT AUTHORIZED TO REDIRECT THIS PAGE. GO BACK to <a href='index.php'> DASHBOARD </a></h3>";
            }

?>                
       </form>   
  </div> 
    </div> 
</div>
</div>
</body> 
</html>