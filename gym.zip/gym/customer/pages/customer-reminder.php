<?php
session_start();
//the isset function to check username is already loged in and stored on the session
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css">
	<style>
	.alert.alert-danger {
		color: #721c24;
		background-color: #f8d7da;
		border: 1px solid #f5c6cb;
		padding: 0.75rem 1.25rem;
		margin-bottom: 1rem;
		border-radius: 0.25rem;
	}
	.alert.alert-success {
		color: #155724;
		background-color: #d4edda;
		border: 1px solid #c3e6cb;
		padding: 0.75rem 1.25rem;
		margin-bottom: 1rem;
		border-radius: 0.25rem;
	}
	.alert .alert-heading {
		font-weight: bold;
		color: #155724;
	}
	</style>
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Payment Reminders</h1>
        </div> 
        <div class="report-body">
	  <?php

      include "dbcon.php";
      $qry="SELECT reminder FROM members WHERE user_id='".$_SESSION['user_id']."'";
      $cnt = 1;
        $result=mysqli_query($con,$qry);

            while($row=mysqli_fetch_array($result)){ ?>

              <?php if($row['reminder'] == '1') { ?>
            
                <div class="alert alert-danger" role="alert">
                <h4 class="alert-heading">ALERT</h4>
                <p>This is to notify you that your current membership program is going to expire soon. Please clear up your payments before your due dates. <br>IT IS IMPORTANT THAT YOU CLEAR YOUR DUES ON TIME IN ORDER TO AVOID SERVICE DISRUPTIONS.</p>
                <hr>
                <p class="mb-0">We value you as our customer and look forward to continue serving you in the future.</p>
              </div>

              <?php } else { ?>

                <div class="alert alert-success" role="alert">
                <h4 class="alert-heading">NO REMINDERS YET!</h4>
              </div>

                <?php } }?>
</div> 
    </div> 
</div>
</div>
</body> 
</html>