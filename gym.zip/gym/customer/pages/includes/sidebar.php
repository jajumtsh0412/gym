<nav>
  <ul class="menu">
    <li>
		<a href="index.php">Dashboard</a>
	</li>
    <li>
		<a href="to-do.php">To-Do</a>
	</li>
    <li>
		<a href="customer-reminder.php">Reminders</a>
	</li>
    <li>
		<a href="announcement.php">Announcement</a>
	</li>
    <li>
		<a href="my-report.php">Reports</a>
	</li>
  </ul>
</nav>