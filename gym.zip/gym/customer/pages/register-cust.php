<!DOCTYPE html>
<html lang="en">
<head>
<title>Gym System Admin</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<style>
body {
  background-color: #328f8a;
  background-image: linear-gradient(45deg,#328f8a,#08ac4b);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
  .custom-container {
    width: 100%;
    margin: 0 auto;
  }

  .custom-row {
    display: flex;
    justify-content: center;
  }

  .custom-column {
    width: 100%;
    max-width: 500px; /* Adjust the max-width as needed */
	padding: 8% 0 0;
	margin: auto;
  }

  .custom-widget-box {
    border: 1px solid #ddd;
    padding: 20px;
    margin-top: 20px;
	background: #FFFFFF;
	border-radius: 30px 0px 30px 0px;
  }

  .custom-widget-title {
    background-color: #f5f5f5;
    padding: 10px;
  }

  .custom-icon {
    color: #333;
  }

  .error-heading {
    color: maroon;
  }

  .error-message {
    color: #333;
  }

  .error-description {
    color: #666;
  }

  .custom-btn {
    display: inline-block;
    padding: 10px 20px;
    background-color: #ffc107; /* Bootstrap warning color */
    color: #333;
    text-decoration: none;
    border-radius: 5px;
    margin-top: 15px;
  }

  .custom-btn:hover {
    background-color: #ff9800; /* Bootstrap warning color on hover */
  }
</style>
</head>
<body>
<form role="form" action="index.php" method="POST">
            <?php 

if(isset($_POST['fullname'])){
$fullname = $_POST["fullname"];    
$username = $_POST["username"];
$password = $_POST["password"];
$gender = $_POST["gender"];
$services = $_POST["services"];
$plan = $_POST["plan"];
$address = $_POST["address"];
$contact = $_POST["contact"];

$password = md5($password);

include 'dbcon.php';
//code after connection is successfull
$qry = "insert into members(fullname,username,password,dor,gender,services,amount,plan,address,contact,status) values ('$fullname','$username','$password', CURRENT_TIMESTAMP,'$gender','$services','0','$plan','$address','$contact','Pending')";
$result = mysqli_query($con,$qry); //query executes

if(!$result){
echo "<div class='custom-container'>";
	echo "<div class='custom-row'>";
	echo "<div class='custom-column'>";
	echo "<div class='custom-widget-box'>";
	echo "<div class='custom-widget-title'>";
		echo "<h1>Error Message</h1>";
	echo "</div>";
	echo "<div class='custom-widget-content'>";
		echo "<div class='custom-error-ex'>";
			echo "<h1 style='color: maroon;'>Error 404</h1>";
			echo "<h3>Error occurred while entering your details</h3>";
			echo "<p>Please Try Again</p>";
			echo "<a class='custom-btn custom-btn-warning custom-btn-big' href='../pages/index.php'>Go Back</a> </div>";
		echo "</div>";
	echo "</div>";
	echo "</div>";
	echo "</div>";
echo "</div>";

}else {
	
echo "<div class='custom-container'>";
	echo "<div class='custom-row'>";
	echo "<div class='custom-column'>";
	echo "<div class='custom-widget-box'>";
	echo "<div class='custom-widget-title'>";
		echo "<h1>Message</h1>";
	echo "</div>";
	echo "<div class='custom-widget-content'>";
		echo "<div class='custom-error-ex'>";
			echo "<h1>Success</h1>";
			echo "<h3>Member details has been added!</h3>";
			echo "<p>The requested details are added. Please wait for the verification.</p>";
			echo "<a class='custom-btn custom-btn-warning custom-btn-big' href='../pages/index.php'>Go Back</a> </div>";
		echo "</div>";
	echo "</div>";
	echo "</div>";
	echo "</div>";
echo "</div>";

}

}else{
    echo"<h3>YOU ARE NOT AUTHORIZED TO REDIRECT THIS PAGE. GO BACK to <a href='index.php'> DASHBOARD </a></h3>";
}


?>
</form>
</body>
</html>