<?php session_start();
include('dbcon.php'); ?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="../css/custom.css">
<title> Perfect Gym System </title>
</head>
<body>
  <body>
    <div class="login-page">
      <div class="form">
        <div class="login">
          <div class="login-header">
            <h3><img src="img/icontest3.png" alt="Logo" /></h3>
            <p>Please enter your credentials to login.</p>
          </div>
        </div>
        <form method="POST" class="login-form" action="#">
          <input type="text" name="user" placeholder="Username" />
          <input type="password" name="pass" placeholder="Password" />
          <input type="submit" name="login" value="login" />
          <p class="message"><a href="../index.php">Go Back</a> &nbsp &nbsp &nbsp | &nbsp &nbsp &nbsp <a href="register.php">Join Now</a></p>
        </form>
		<?php
                if (isset($_POST['login']))
                    {
                        $username = mysqli_real_escape_string($con, $_POST['user']);
                        $password = mysqli_real_escape_string($con, $_POST['pass']);

                        $password = md5($password);
                        
                        $query 		= mysqli_query($con, "SELECT * FROM members WHERE  password='$password' and username='$username' and status='Active'");
                        $row		= mysqli_fetch_array($query);
                        $num_row 	= mysqli_num_rows($query);
                        
                        if ($num_row > 0) 
                            {			
                                $_SESSION['user_id']=$row['user_id'];
                                header('location:pages/index.php');
                                
                            }
                        else
                            {
                                echo "<div class='alert alert-danger alert-dismissible' role='alert'>
                                Invalid Username/Password or Account has been Expired!
                                <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                                    <span aria-hidden='true'>&times;</span>
                                </button>
                                </div>";
                            }
                    }
            ?>
      </div>
    </div>
</body>
</body>
</html>
