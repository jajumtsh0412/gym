<?php
    session_start();
    include('dbcon.php');
    
    if (isset($_POST['login'])) {
        $username = $_POST['user'];
        $password = $_POST['pass'];

        $password = md5($password);

        $q = "SELECT * FROM staffs WHERE  password='$password' and username='$username'";

        $query 		= mysqli_query($conn, $q);
        $row		= mysqli_fetch_array($query);
        $num_row 	= mysqli_num_rows($query);

        if ($num_row > 0) {			
            $_SESSION['user_id']=$row['user_id'];
            header('location:staff-pages/index.php');
        } else {
            echo "<div class='alert alert-danger alert-dismissible' role='alert'>
                    Invalid Username and Password
                </div>";
        }
    }
    else{
        echo "Error Processing Data";
    }
?>