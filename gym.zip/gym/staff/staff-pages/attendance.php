<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css"> 
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Attendance Table</h1>
        </div> 
        <div class="report-body">
	  
	  <?php
      include "dbcon.php";
          echo"<table id='report-table'>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Fullname</th>
                  <th>Contact Number</th>
                  <th>Choosen Service</th>
                  <th>Action</th>
                </tr>
              </thead>";

              date_default_timezone_set('Asia/Kathmandu');
                 $current_date = date('Y-m-d h:i A');
                $exp_date_time = explode(' ', $current_date);
                 $todays_date =  $exp_date_time['0'];
                     $qry="select * from members";
                    $result=mysqli_query($con,$qry);
                   $i=1;
              $cnt = 1;
            while($row=mysqli_fetch_array($result)){ ?>
            
           <tbody> 
               
                <td><div class='text-center'><?php echo $cnt; ?></div></td>
                <td><div class='text-center'><?php echo $row['fullname']; ?></div></td>
                <td><div class='text-center'><?php echo $row['contact']; ?></div></td>
                <td><div class='text-center'><?php echo $row['services']; ?></div></td>

                <input type="hidden" name="user_id" value="<?php echo $row['user_id'];?>">

            <?php
				$curr_date = "";
                $qry = "SELECT * FROM attendance WHERE curr_date = '$todays_date' AND user_id = '".$row['user_id']."'";
                $res = $con->query($qry);
                $num_count  = mysqli_num_rows($res);
                $row_exist = mysqli_fetch_array($res);
				if($num_count>0)
				{
					$curr_date = $row_exist['curr_date'];
				}
                if($curr_date != "" && $curr_date == $todays_date){
  
              ?>
                <td>
                <div class='text-center'><span class="label label-inverse"><?php echo $row_exist['curr_date'];?>  <?php echo $row_exist['curr_time'];?></span></div>
                <div class='text-center'><a href='actions/delete-attendance.php?id=<?php echo $row['user_id'];?>'>Check Out</a></div>
                </td>

            <?php } else {
                
                ?>

                <td><div class='text-center'><a class='btn btn-inverse' href='actions/check-attendance.php?id=<?php echo $row['user_id'];?>'>Check In</a></div></td>
             
                <?php }
              ?>      
              </tbody>
           <?php $cnt++; } ?>
           

            </table>
            </div> 
    </div> 
</div> 

	</div> 

	<script src="../js/index.js"></script> 
</body> 
</html>