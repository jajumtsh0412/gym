<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css"> 
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Add Member</h1>
        </div> 
        <div class="report-body"> 
<form role="form" action="index.php" method="POST">
            <?php 

if(isset($_POST['fullname'])){
  $fullname = $_POST["fullname"];    
  $username = $_POST["username"];
  $password = $_POST["password"];
  $dor = $_POST["dor"];
  $gender = $_POST["gender"];
  $services = $_POST["services"];
  $amount = $_POST["amount"];
  $p_year = date('Y');
  $paid_date = date("Y-m-d");
  $plan = $_POST["plan"];
  $address = $_POST["address"];
  $contact = $_POST["contact"];

  $password = md5($password);

  $totalamount = $amount * $plan;
include 'dbcon.php';
$qry = "INSERT INTO members(fullname,username,password,dor,gender,services,amount,p_year,paid_date,plan,address,contact) values ('$fullname','$username','$password','$dor','$gender','$services','$totalamount','$p_year','$paid_date','$plan','$address','$contact')";
$result = mysqli_query($con,$qry); //query executes

if(!$result){
  echo"<div class='container-fluid'>";
      echo"<div class='row-fluid'>";
      echo"<div class='span12'>";
      echo"<div class='widget-box'>";
      echo"<div class='widget-title'> <span class='icon'> <i class='fas fa-info'></i> </span>";
          echo"<h5>Error Message</h5>";
          echo"</div>";
          echo"<div class='widget-content'>";
              echo"<div class='error_ex'>";
              echo"<h1 style='color:maroon;'>Error 404</h1>";
              echo"<h3>Error occured while entering your details</h3>";
              echo"<p>Please Try Again</p>";
              echo"<a class='btn btn-warning btn-big'  href='edit-member.php'>Go Back</a> </div>";
          echo"</div>";
          echo"</div>";
      echo"</div>";
      echo"</div>";
  echo"</div>";
}else {

  echo"<div class='container-fluid'>";
      echo"<div class='row-fluid'>";
      echo"<div class='span12'>";
      echo"<div class='widget-box'>";
      echo"<div class='widget-title'> <span class='icon'> <i class='fas fa-info'></i> </span>";
          echo"<h5>Message</h5>";
          echo"</div>";
          echo"<div class='widget-content'>";
              echo"<div class='error_ex'>";
              echo"<h1>Success</h1>";
              echo"<h3>Member details has been added!</h3>";
              echo"<p>The requested details are added. Please click the button to go back.</p>";
              echo"<a class='btn btn-inverse btn-big'  href='members.php'>Go Back</a> </div>";
          echo"</div>";
          echo"</div>";
      echo"</div>";
      echo"</div>";
  echo"</div>";

}

}else{
    echo"<h3>YOU ARE NOT AUTHORIZED TO REDIRECT THIS PAGE. GO BACK to <a href='index.php'> DASHBOARD </a></h3>";
}


?>
                                    
                                
                                        
                
    </form>
 </div> 
    </div> 
</div> 

	</div> 

	<script src="../js/index.js"></script> 
</body> 
</html>