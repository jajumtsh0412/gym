<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css"> 
  <style>
    form {
      padding: 20px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 15px;
    }

    table, th, td {
      border: 1px solid #ddd;
    }

    th, td {
      padding: 10px;
      text-align: left;
    }

    .form-actions {
      text-align: center;
      margin-top: 20px;
    }

    .btn {
      background-color: #5cb85c;
      color: #fff;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .btn:hover {
      background-color: #4cae4c;
    }
    input {
    width: 70%;
    padding: 8px;
    margin-top: 4px;
    margin-bottom: 8px;
    box-sizing: border-box;
  }

  select {
    width: 70%;
    padding: 8px;
    margin-top: 4px;
    margin-bottom: 8px;
    box-sizing: border-box;
  }
  </style>
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Update Staff's Detail</h1>
        </div> 
        <div class="report-body">

<?php
include 'dbcon.php';
$id=$_GET['id'];
$qry= "select * from staffs where user_id='$id'";
$result=mysqli_query($con,$qry);
while($row=mysqli_fetch_array($result)){
?> 
  <form action="edit-staff-req.php" method="POST">
    <table>
      <tr>
        <td>Full Name:</td>
        <td><input type="text" name="fullname" value='<?php echo $row['fullname']; ?>'></td>
      </tr>
      <tr>
        <td>Username:</td>
        <td><input type="text" name="username" value='<?php echo $row['username']; ?>'></td>
      </tr>
      <tr>
        <td>Password:</td>
        <td>
          <input type="password" name="password" disabled="" placeholder="**********"><br>
          <span>Note: Only the members are allowed to change their password until and unless it's an emergency.</span>
        </td>
      </tr>
      <tr>
        <td>Gender:</td>
        <td><input type="text" name="gender" value='<?php echo $row['gender']; ?>'></td>
      </tr>
      <tr>
        <td>Contact Number:</td>
        <td>
          <input type="number" id="mask-phone" placeholder="(999) 999-9999" name="contact" value='<?php echo $row['contact']; ?>'>
        </td>
      </tr>
      <tr>
        <td>Address:</td>
        <td><input type="text" name="address" value='<?php echo $row['address']; ?>'></td>
      </tr>
      <tr>
        <td>Designation:</td>
        <td>
          <select name="designation" id="designation">
            <option value="Cashier">Cashier</option>
            <option value="Trainer">Trainer</option>
            <option value="GYM Assistant">GYM Assistant</option>
            <option value="Front Desk Staff">Front Desk Staff</option>
            <option value="Manager">Manager</option>
          </select>
        </td>
      </tr>
    </table>
    <div class="form-actions">
      <input type="hidden" name="id" value="<?php echo $row['user_id'];?>">
      <button type="submit" class="btn">Update Staff Details</button>
    </div>
  </form>
<?php } ?>
</div> 
    </div> 
</div> 

	</div> 

	<script src="../js/index.js"></script> 
</body> 
</html>