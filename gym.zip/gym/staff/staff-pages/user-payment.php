<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css">
<style>
  input {
    width: 70%;
    padding: 8px;
    margin-top: 4px;
    margin-bottom: 8px;
    box-sizing: border-box;
  }
</style>
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Payment Form</h1>
        </div> 
        <div class="report-body">
<?php
include 'dbcon.php';
$id=$_GET['id'];
$qry= "select * from members where user_id='$id'";
$result=mysqli_query($con,$qry);
while($row=mysqli_fetch_array($result)){
?>
<form action="userpay.php" method="POST">
<table id="report-table">
    <tbody>
        <tr>
            <td>Member's Fullname:</td>
            <td><input type="text" name="fullname" value="<?php echo $row['fullname']; ?>"></td>
        </tr>
        <tr>
            <td>Service:</td>
            <td><input type="text" name="services" value="<?php echo $row['services']; ?>"></td>
        </tr>
        <tr>
            <td>Amount Per Month:</td>
            <td><input type="number" name="amount" value='<?php if($row['services'] == 'Fitness') { echo '55';} elseif ($row['services'] == 'Sauna') { echo '35';} else {echo '40';} ?>' /></td>
        </tr>
        <tr>
            <td>Plan:</td>
            <td>
                <select name="plan" required="required">
                    <option value="1" selected="selected" >One Month</option>
                    <option value="3">Three Month</option>
                    <option value="6">Six Month</option>
                    <option value="12">One Year</option>
                    <option value="0">None-Expired</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>Member's Status:</td>
            <td>
                <select name="status" required="required">
                    <option value="Active" selected="selected" >Active</option>
                    <option value="Expired">Expired</option>
                </select>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="hidden" name="paid_date" value="<?php echo $row['paid_date']; ?>">
                <input type="hidden" name="id" value="<?php echo $row['user_id'];?>">
                <div>
                    <button class="btn btn-inverse btn-big" type="submit">Make Payment</button>
                </div>
            </td>
        </tr>
    </tbody>
</table>
</form>
</div>
<?php } ?>

          </div> 
    </div> 
</div> 

	</div> 

	<script src="../js/index.js"></script> 
</body> 
</html>