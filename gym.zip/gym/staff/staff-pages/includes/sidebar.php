<nav>
	<ul class="menu">
		<li>
			<a href="index.php">Dashboard</a>
		</li>
		<li>
			<a href="#">Manage Members</a>
			<ul class="sub-menu">
				<li><a href="members.php">List All Members</a></li>
				<li><a href="member-entry.php">Member Entry Form</a></li>
				<li><a href="remove-member.php">Remove Member</a></li>
				<li><a href="edit-member.php">Update Member Details</a></li>
			</ul>
		</li>
		<li>
			<a href="#">Gym Equipment</a>
			<ul class="sub-menu">
				<li><a href="equipment.php">List Gym Equipment</a></li>
				<li><a href="equipment-entry.php">Add Equipment</a></li>
				<li><a href="remove-equipment.php">Remove Equipment</a></li>
				<li><a href="edit-equipment.php">Update Equipment Details</a></li>
			</ul>
		</li>
		<li>
			<a href="attendance.php">Manage Attendance</a>
		</li>
		<li>
			<a href="member-status.php">Member's Status</a>
		</li>
		<li>
			<a href="payment.php">Payments</a>
		</li>
	</ul>
</nav>