<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css"> 
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Update Equipment</h1>
        </div> 
        <div class="report-body">
<form role="form" action="index.php" method="POST">
    <?php 

            if(isset($_POST['name'])){
            $name = $_POST["name"];    
            $amount = $_POST["amount"];
            $vendor = $_POST["vendor"];
            $description = $_POST["description"];
            $address = $_POST["address"];
            $contact = $_POST["contact"];
            $date = $_POST["date"];
            $quantity = $_POST["quantity"];
            $id=$_POST['id'];

            $totalamount = $amount * $quantity;
            
            include 'dbcon.php';
            
            $qry = "update equipment set name='$name', amount='$totalamount',vendor='$vendor', description='$description', address='$address', address='$address', contact='$contact', date='$date', quantity='$quantity' where id='$id'";
            $result = mysqli_query($con,$qry); 

            if(!$result){
                            echo"<h1 style='color:maroon;'>Error 404</h1>";
                            echo"<h3>Error occured while updating your details</h3>";
                            echo"<p>Please Try Again</p>";
                            echo"<a class='btn btn-warning btn-big'  href='edit-equipment.php'>Go Back</a>";
            }else {
                            echo"<h1>Success</h1>";
                            echo"<h3>Equipment details has been updated!</h3>";
                            echo"<p>The requested details are updated. Please click the button to go back.</p>";
                            echo"<a class='btn btn-inverse btn-big'  href='equipment.php'>Go Back</a>";
            }

            }else{
                echo"<h3>YOU ARE NOT AUTHORIZED TO REDIRECT THIS PAGE. GO BACK to <a href='index.php'> DASHBOARD </a></h3>";
            }
?>   
             </form>
             </div> 
    </div> 
</div> 

	</div> 

	<script src="../js/index.js"></script> 
</body> 
</html>