<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
	exit;
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css"> 
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Dashboard</h1>
        </div> 
        <div class="report-body">
	
        <h3 class="head">Gym Announcement</h3>
		<br>
        <?php
            include "dbcon.php";
            $qry="select * from announcements";
            $result=mysqli_query($con,$qry);

            echo"<table id='report-table'>
              <thead>
                <tr>
                  <th>Message</th>
                  <th>Date</th>
                  <th>Author</th>
                </tr>
              </thead><tbody>";
              while($row=mysqli_fetch_array($result)){
              echo"<tr>
                  <td>".$row['message']."</td>
                  <td><span class='in-progress'>".$row['date']."</span></td>
                  <td>System Administrator</td>
                </tr>";
			  }
        ?>
			</tbody>
            </table>
			
		<br>
		<hr>
		<br>

		<h3>Customers ToDo List</h3>
		<br>
        <?php
            include "dbcon.php";
            $qry="SELECT * FROM todo";
            $result=mysqli_query($con,$qry);

            echo"<table id='report-table'>
              <thead>
                <tr>
                  <th>Description</th>
                  <th>Status</th>
                  <th>Opts</th>
                </tr>
              </thead><tbody>";
              while($row=mysqli_fetch_array($result)){
              echo"<tr>
                  <td><a href='to-do.php'><i class='icon-plus-sign'></i></a>".$row['task_desc']."</td>
                  <td><span class='in-progress'>".$row['task_status']."</span></td>
                  <td><a href='update-todo.php?id=".$row['id']."' data-original-title='Update'>Edit</a> | <a href='actions/remove-todo.php?id=".$row['id']."' data-original-title='Done'>Remove</a></td>
                </tr>";
			  }
        ?>
			</tbody>
            </table>
</div> 
    </div> 
</div> 

	</div> 

	<script src="../js/index.js"></script> 
</body> 
</html>