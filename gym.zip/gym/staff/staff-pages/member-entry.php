<?php
session_start();
if(!isset($_SESSION['user_id'])){
    header('location:../index.php');	
}
?>
<!DOCTYPE html> 
<html lang="en"> 
<head> 
	<meta charset="UTF-8"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0"> 
	<title>Perfect GYM System</title> 
	<link rel="stylesheet" href="../css/style.css"> 
	<link rel="stylesheet" href="../css/responsive.css">
	<style>
        form {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
			width: 100%;
        }

        table {
            width: 100%;
        }

        td {
            padding: 8px;
        }
		
		input{
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
            margin-bottom: 10px;
        }
		
		select{
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
            margin-bottom: 10px;
        }

        radio {
			display: block;
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
            margin-bottom: 10px;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
</head> 

<body>
	<?php include("includes/topheader.php"); ?>
	<?php include("includes/sidebar.php"); ?>
	<div class="main-container">
	<div class="main">
    <div class="report-container"> 
        <div class="report-header"> 
            <h1 class="recent-Articles">Member Entry Form</h1>
        </div> 
        <div class="report-body">
		<form action="add-member-req.php" method="POST">
    <table>
        <tr>
            <td>Full Name:</td>
            <td><input type="text" name="fullname" placeholder="Fullname" required></td>
        </tr>
        <tr>
            <td>Username:</td>
            <td><input type="text" name="username" placeholder="Username" required></td>
        </tr>
        <tr>
            <td>Password:</td>
            <td><input type="password" name="password" placeholder="**********" required></td>
        </tr>
        <tr>
            <td>Gender:</td>
            <td>
                <select name="gender" required>
                    <option value="Male" selected>Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>Date of Registration:</td>
            <td><input type="date" name="dor" required></td>
        </tr>
        <tr>
            <td>Plan:</td>
            <td>
                <select name="plan" required>
                    <option value="1" selected>One Month</option>
                    <option value="3">Three Month</option>
                    <option value="6">Six Month</option>
                    <option value="12">One Year</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>Contact Number:</td>
            <td><input type="number" name="contact" placeholder="9876543210" required></td>
        </tr>
        <tr>
            <td>Address:</td>
            <td><input type="text" name="address" placeholder="Address" required></td>
        </tr>
        <tr>
            <td>Services:</td>
            <td>
               <select name"Services" required>
					<option value="Fitness" selected>Fitness - $55 per month</option>
					<option value="Sauna" >Sauna - $35 per month</option>
					<option value="Cardio" >Cardio - $40 per month</option>
			   </select>
            </td>
        </tr>
        <tr>
            <td>Total Amount($):</td>
            <td>
                <input type="number" name="amount" placeholder="50" required>
            </td>
        </tr>
        <tr>
            <td colspan="2" align="center">
                <button type="submit">Submit Member Details</button>
            </td>
        </tr>
    </table>
</form>
</div> 
    </div> 
</div> 

	</div> 

	<script src="../js/index.js"></script> 
</body> 
</html>
