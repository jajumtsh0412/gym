<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="../css/custom.css">
<title> Perfect Gym System </title>
</head>
<body>
  <body>
    <div class="login-page">
      <div class="form">
        <div class="login">
          <div class="login-header">
            <h3><img src="img/icontest3.png" alt="Logo" /></h3>
            <p>Please enter your credentials to login.</p>
          </div>
        </div>
        <form method="POST" class="login-form" action="user_login.php">
          <input type="text" name="user" placeholder="username"/>
          <input type="password" name="pass" placeholder="password"/>
          <input type="submit" name="login" value="login" />
          <p class="message"><a href="../index.php">Admin Login</a> &nbsp &nbsp &nbsp | &nbsp &nbsp &nbsp <a href="../customer/index.php">Customer Login</a></p>
        </form>
        <?php
          session_start();
          include('dbcon.php');
          
          if (isset($_POST['login'])) {
              $username = $_POST['user'];
              $password = $_POST['pass'];

              $password = md5($password);

              $q = "SELECT * FROM staffs WHERE  password='$password' and username='$username'";

              $query 		= mysqli_query($conn, $q);
              $row		= mysqli_fetch_array($query);
              $num_row 	= mysqli_num_rows($query);

              if ($num_row > 0) {			
                  $_SESSION['user_id']=$row['user_id'];
                  header('location:staff-pages/index.php');
              } else {
                  echo "<div class='alert alert-danger alert-dismissible' role='alert'>
                          Invalid Username and Password
                      </div>";
              }
          }
        ?>
      </div>
    </div>
</body>
</body>
</html>